/*
 * ESP32 SSD1306 128x32 OLED using the modern U8g2 library
 *
 * Description: A polling-driven hierarchical menu system for the ESP32 and SSD1306 display.
 *              *** MODIFIED: No Interrupts used. Polling check in loop. ***
 *              *** MODIFIED: Actions trigger on button RELEASE. ***
 *              *** MODIFIED: Long press updates screen immediately upon duration expiry. ***
 *
 * Navigation:
 * - Button 1 (Up):    Moves the selection up (Action on Release).
 * - Button 2 (Down):  Moves the selection down (Action on Release).
 * - Button 3 (Short): Selects an item (Action on Release).
 * - Button 3 (Hold):  Goes back to the previous menu level (Action immediately after hold duration).
 */

// Core Arduino and the modern U8g2 library
#include <Arduino.h>
#include <U8g2lib.h>
#include <Wire.h>

// --- Debug Macro ---
#define DEBUG 1
#if DEBUG
#define DEBUG_PRINT(x) Serial.print(x)
#define DEBUG_PRINTLN(x) Serial.println(x)
#else
#define DEBUG_PRINT(x)
#define DEBUG_PRINTLN(x)
#endif

// --- Pin Definitions ---
#define SDA 10
#define SCL 4

#define BUTTON1 9   // Up
#define BUTTON2 20  // Down
#define BUTTON3 21  // Select / Back (Hold)

// --- U8g2 Display Object Instantiation ---
U8G2_SSD1306_128X32_UNIVISION_F_HW_I2C u8g2(U8G2_R0, /* reset=*/U8X8_PIN_NONE, /* clock=*/SCL, /* data=*/SDA);


// --- BITMAP DATA ---

// 'battery_icon', 16x16px
const unsigned char epd_bitmap_battery_icon[] PROGMEM = {
  0x00, 0x00, 0xc0, 0x03, 0xc0, 0x03, 0xf0, 0x0f, 0x10, 0x08, 0xd0, 0x0b, 0xd0, 0x0b, 0x10, 0x08,
  0xd0, 0x0b, 0xd0, 0x0b, 0x10, 0x08, 0xd0, 0x0b, 0xd0, 0x0b, 0x10, 0x08, 0xf0, 0x0f, 0x00, 0x00
};
// 'folder_icon', 16x16px
const unsigned char epd_bitmap_folder_icon[] PROGMEM = {
  0x00, 0x00, 0x3f, 0x00, 0xe1, 0x3f, 0x01, 0x20, 0x01, 0x20, 0x01, 0xff, 0x81, 0x80, 0x7d, 0x80,
  0x05, 0x80, 0x03, 0x40, 0x03, 0x40, 0x03, 0x20, 0xff, 0x3f, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};
// 'gps_icon', 16x16px
const unsigned char epd_bitmap_gps_icon[] PROGMEM = {
  0x38, 0x00, 0x04, 0x00, 0x32, 0x00, 0x09, 0x30, 0x25, 0x48, 0x15, 0x84, 0x80, 0x83, 0xc0, 0x43,
  0xc0, 0x27, 0xc0, 0x1f, 0x20, 0x1f, 0x10, 0x1e, 0x08, 0x0e, 0x08, 0x01, 0x90, 0x00, 0x60, 0x00
};
// 'location_icon', 16x16px
const unsigned char epd_bitmap_location_icon[] PROGMEM = {
  0xc0, 0x07, 0x60, 0x0c, 0xb0, 0x1b, 0xd0, 0x17, 0xd0, 0x17, 0xd0, 0x17, 0xf0, 0x1f, 0xe0, 0x0f,
  0xc0, 0x07, 0x80, 0x03, 0x80, 0x03, 0x80, 0x03, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00
};
// 'placeholder_icon', 16x16px
const unsigned char epd_bitmap_placeholder_icon[] PROGMEM = {
  0x00, 0x00, 0x00, 0x00, 0xf0, 0x07, 0xf0, 0x0f, 0x30, 0x0c, 0x30, 0x0c, 0x30, 0x0c, 0xf0, 0x0f,
  0xf0, 0x07, 0x30, 0x00, 0x30, 0x00, 0x30, 0x00, 0x30, 0x00, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00
};
// 'settings_icon', 16x16px
const unsigned char epd_bitmap_settings_icon[] PROGMEM = {
  0x00, 0x00, 0x00, 0x00, 0x80, 0x01, 0x90, 0x09, 0xb8, 0x1d, 0xf0, 0x0f, 0x60, 0x06, 0x3c, 0x3c,
  0x3c, 0x3c, 0x60, 0x06, 0xf0, 0x0f, 0xb8, 0x1d, 0x90, 0x09, 0x80, 0x01, 0x00, 0x00, 0x00, 0x00
};
// 'track_shot_icon', 16x16px
const unsigned char epd_bitmap_track_shot_icon[] PROGMEM = {
  0x00, 0x00, 0x80, 0x01, 0x80, 0x01, 0x18, 0x18, 0x18, 0x18, 0x00, 0x00, 0x06, 0x60, 0x06, 0x60,
  0x00, 0x00, 0x03, 0xc0, 0x03, 0xc0, 0x00, 0x00, 0x88, 0x88, 0xaa, 0xaa, 0xff, 0xff, 0x00, 0x00
};
// 'hierarchy_marker', 8x8px
const unsigned char epd_bitmap_hierarchy_marker[] PROGMEM = {
  0x0f, 0x0f, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};
// 'scroll_bar_knob', 8x8px
const unsigned char epd_bitmap_scroll_bar_knob[] PROGMEM = {
  0x00, 0xe0, 0xe0, 0xe0, 0xe0, 0xe0, 0x00, 0x00
};
// 'down_arrow', 16x8px
const unsigned char epd_bitmap_down_arrow[] PROGMEM = {
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xf8, 0x1f, 0xe0, 0x07, 0x80, 0x01, 0x00, 0x00
};
// 'up_arrow', 16x8px
const unsigned char epd_bitmap_up_arrow[] PROGMEM = {
  0x00, 0x00, 0x80, 0x01, 0xe0, 0x07, 0xf8, 0x1f, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};
// 'scroll_bar', 8x32px
const unsigned char epd_bitmap_scroll_bar[] PROGMEM = {
  0x00, 0x40, 0x00, 0x40, 0x00, 0x40, 0x00, 0x40, 0x00, 0x40, 0x00, 0x40, 0x00, 0x40, 0x00, 0x40,
  0x00, 0x40, 0x00, 0x40, 0x00, 0x40, 0x00, 0x40, 0x00, 0x40, 0x00, 0x40, 0x00, 0x40, 0x00, 0x00
};
// 'item_outline', 128x32px
const unsigned char epd_bitmap_item_outline[] PROGMEM = {
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0xf8, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x03,
  0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c,
  0xfc, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x07,
  0xf8, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x03,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

// --- MENU DEFINITION ---

struct MenuItem {
  const char* title;
  const unsigned char* icon;
  int8_t parent;
  uint8_t firstChild;
  uint8_t numChildren;
  bool isAction;
};

// Define the entire menu structure in a single array
MenuItem menuItems[] = {
  // Index 0: Main Menu (Root)
  { "Main Menu", nullptr, -1, 1, 3, false },
  // Children of Main Menu (Parent: 0)
  { "Track Shot", epd_bitmap_track_shot_icon, 0, 4, 1, false },
  { "Shot Log", epd_bitmap_folder_icon, 0, 5, 3, false },
  { "Settings", epd_bitmap_settings_icon, 0, 8, 2, false },

  // Index 4: Track Shot Submenu
  { "Place Point", epd_bitmap_placeholder_icon, 1, 0, 0, true },

  // Index 5: Shot Log Submenu
  { "Club 1", epd_bitmap_placeholder_icon, 2, 0, 0, true },
  { "Club 2", epd_bitmap_placeholder_icon, 2, 0, 0, true },
  { "Club 3", epd_bitmap_placeholder_icon, 2, 0, 0, true },

  // Index 8: Settings Submenu
  { "Reset GPS", epd_bitmap_gps_icon, 3, 0, 0, true },
  { "Battery", epd_bitmap_battery_icon, 3, 0, 0, true }
};

// --- State Management Variables ---
struct UIState {
  int currentMenuIndex;
  int currentSelection;
};
UIState ui = { 0, 0 };  // Initialize to root menu

bool displayNeedsUpdate = true;
unsigned long actionScreenVisibleUntil = 0;

// --- Button State Tracking (Polling) ---
const unsigned long LONG_PRESS_DURATION = 700;
const unsigned long DEBOUNCE_DELAY = 40;

// Button 1 Variables
int lastB1State = LOW;
int currentB1State = LOW;
unsigned long lastB1DebounceTime = 0;

// Button 2 Variables
int lastB2State = LOW;
int currentB2State = LOW;
unsigned long lastB2DebounceTime = 0;

// Button 3 Variables
int lastB3State = LOW;
int currentB3State = LOW;
unsigned long lastB3DebounceTime = 0;
unsigned long b3PressStartTime = 0;
bool b3IsHeld = false;
bool b3LongActionTaken = false;


// --- Function Prototypes ---
void checkButtons();
void drawMenu();
void drawActionScreen(const char* actionText);
int getMenuDepth();


void setup(void) {
  Serial.begin(115200);
  DEBUG_PRINTLN("\n--- System Setup ---");

  DEBUG_PRINTLN("Initializing pins for external pull-down resistors...");
  pinMode(BUTTON1, INPUT_PULLUP);
  pinMode(BUTTON2, INPUT_PULLUP);
  pinMode(BUTTON3, INPUT_PULLUP);

  // Removed: attachInterrupt calls

  DEBUG_PRINTLN("Initializing display...");
  u8g2.begin();

  DEBUG_PRINTLN("Setup complete. Loop starting.");
}

void loop(void) {
  // Check button states periodically
  checkButtons();

  // Check if the action screen's visibility duration has expired
  if (actionScreenVisibleUntil > 0 && millis() >= actionScreenVisibleUntil) {
    displayNeedsUpdate = true;     // Trigger a redraw of the menu
    actionScreenVisibleUntil = 0;  // Reset the timer
  }

  // Only update the display if something has changed
  if (displayNeedsUpdate) {
    DEBUG_PRINTLN("\n----- Display Update Triggered -----");
    // Do not draw the menu if an action screen is meant to be visible
    if (actionScreenVisibleUntil == 0) {
      drawMenu();
    }
    displayNeedsUpdate = false;  // Reset the flag
  }
}

void checkButtons() {
  unsigned long currentMillis = millis();

  // -----------------------------
  // BUTTON 1 (UP) - Action on Release
  // -----------------------------
  int reading1 = digitalRead(BUTTON1);
  if (reading1 != lastB1State) {
    lastB1DebounceTime = currentMillis;
  }

  if ((currentMillis - lastB1DebounceTime) > DEBOUNCE_DELAY) {
    if (reading1 != currentB1State) {
      currentB1State = reading1;
      // Trigger action only when transitioning from HIGH to LOW (Release)
      if (currentB1State == HIGH) {
        DEBUG_PRINTLN("Button 1 Released (UP)");
        ui.currentSelection--;
        if (ui.currentSelection < 0) {
          ui.currentSelection = menuItems[ui.currentMenuIndex].numChildren - 1;
        }
        displayNeedsUpdate = true;
      }
    }
  }
  lastB1State = reading1;

  // -----------------------------
  // BUTTON 2 (DOWN) - Action on Release
  // -----------------------------
  int reading2 = digitalRead(BUTTON2);
  if (reading2 != lastB2State) {
    lastB2DebounceTime = currentMillis;
  }

  if ((currentMillis - lastB2DebounceTime) > DEBOUNCE_DELAY) {
    if (reading2 != currentB2State) {
      currentB2State = reading2;
      // Trigger action only when transitioning from HIGH to LOW (Release)
      if (currentB2State == HIGH) {
        DEBUG_PRINTLN("Button 2 Released (DOWN)");
        ui.currentSelection++;
        if (ui.currentSelection >= menuItems[ui.currentMenuIndex].numChildren) {
          ui.currentSelection = 0;
        }
        displayNeedsUpdate = true;
      }
    }
  }
  lastB2State = reading2;

  // -----------------------------
  // BUTTON 3 (SELECT / BACK)
  // -----------------------------
  int reading3 = digitalRead(BUTTON3);
  if (reading3 != lastB3State) {
    lastB3DebounceTime = currentMillis;
  }

  if ((currentMillis - lastB3DebounceTime) > DEBOUNCE_DELAY) {
    // Update internal state if stable
    if (reading3 != currentB3State) {
      currentB3State = reading3;

      if (currentB3State == LOW) {
        // PRESS START
        DEBUG_PRINTLN("Button 3 Pressed. Timer started.");
        b3PressStartTime = currentMillis;
        b3IsHeld = true;
        b3LongActionTaken = false;
      } else {
        // RELEASE
        DEBUG_PRINTLN("Button 3 Released.");
        b3IsHeld = false;
        // Only trigger Short Action if Long Action wasn't taken
        if (!b3LongActionTaken) {
          DEBUG_PRINTLN("  > Short Press detected (SELECT).");
          
          int selectedItemIndex = menuItems[ui.currentMenuIndex].firstChild + ui.currentSelection;
          if (menuItems[selectedItemIndex].isAction) {
            drawActionScreen(menuItems[selectedItemIndex].title);
            actionScreenVisibleUntil = millis() + 1500;
          } else if (menuItems[selectedItemIndex].numChildren > 0) {
            ui.currentMenuIndex = selectedItemIndex;
            ui.currentSelection = 0;
            displayNeedsUpdate = true;
          }
        }
      }
    }
  }
  lastB3State = reading3;

  // -----------------------------
  // BUTTON 3 HOLD CHECK (Running Continuously)
  // -----------------------------
  if (b3IsHeld && !b3LongActionTaken) {
    if ((currentMillis - b3PressStartTime) > LONG_PRESS_DURATION) {
      DEBUG_PRINTLN("  > Long Press Duration Exceeded (BACK).");
      b3LongActionTaken = true; // Prevent short press action later
      
      // Action: Go Back
      if (menuItems[ui.currentMenuIndex].parent != -1) {
        ui.currentMenuIndex = menuItems[ui.currentMenuIndex].parent;
        ui.currentSelection = 0;
        // IMMEDIATE UPDATE: Update display while button is still held
        displayNeedsUpdate = true; 
        DEBUG_PRINTLN("  > Navigating back immediately.");
      } else {
        DEBUG_PRINTLN("  > At root, no action.");
      }
    }
  }
}

int getMenuDepth() {
  int depth = 0;
  int tempIndex = ui.currentMenuIndex;
  while (menuItems[tempIndex].parent != -1) {
    tempIndex = menuItems[tempIndex].parent;
    depth++;
  }
  return depth;
}

void drawMenu() {
  u8g2.clearBuffer();
  u8g2.setBitmapMode(1);

  MenuItem currentMenu = menuItems[ui.currentMenuIndex];
  int selectedItemIndex = currentMenu.firstChild + ui.currentSelection;
  MenuItem selectedItem = menuItems[selectedItemIndex];

  // Draw Item Outline
  u8g2.drawXBM(0, 0, 128, 32, epd_bitmap_item_outline);

  // Draw Hierarchy Markers
  int menuDepth = getMenuDepth();
  for (int i = 0; i < menuDepth; i++) {
    u8g2.drawXBM(i * 8, 0, 8, 8, epd_bitmap_hierarchy_marker);
  }

  // Draw Icon and Text
  u8g2.drawXBM(4, 8, 16, 16, selectedItem.icon);
  u8g2.setFont(u8g2_font_7x14B_tf);
  u8g2.drawStr(23, 20, selectedItem.title);

  // Draw Scrollbar
  if (currentMenu.numChildren > 1) {
    u8g2.drawXBM(120, 0, 8, 32, epd_bitmap_scroll_bar);

    if (ui.currentSelection > 0) {
      u8g2.drawXBM(54, 0, 16, 8, epd_bitmap_up_arrow);
    }

    if (ui.currentSelection < currentMenu.numChildren - 1) {
      u8g2.drawXBM(54, 24, 16, 8, epd_bitmap_down_arrow);
    }

    int knobY = map(ui.currentSelection, 0, currentMenu.numChildren - 1, 0, 24);
    u8g2.drawXBM(120, knobY, 8, 8, epd_bitmap_scroll_bar_knob);
  }

  u8g2.sendBuffer();
}

void drawActionScreen(const char* actionText) {
  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_7x14B_tf);

  char buffer[32];
  strcpy(buffer, "Action: ");
  strcat(buffer, actionText);

  u8g2.drawStr(23, 20, buffer);
  u8g2.sendBuffer();
}
